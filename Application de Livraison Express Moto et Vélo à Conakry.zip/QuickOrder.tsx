import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, MapPin, Navigation, CheckCircle, Zap } from "lucide-react";

interface Location {
  lat: number;
  lng: number;
  address: string;
}

export default function QuickOrder() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [productName, setProductName] = useState("");
  const [notes, setNotes] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [transportType, setTransportType] = useState<"bike" | "motorcycle">("bike");
  const [contactMethod, setContactMethod] = useState<"whatsapp" | "sms" | "call">("whatsapp");
  const [gpsLocation, setGpsLocation] = useState<Location | null>(null);
  const [isGpsLoading, setIsGpsLoading] = useState(false);
  const [gpsEnabled, setGpsEnabled] = useState(false);
  const [orderSubmitted, setOrderSubmitted] = useState(false);

  // Request GPS permission on mount
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setGpsLocation({
            lat: latitude,
            lng: longitude,
            address: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
          });
          setGpsEnabled(true);
        },
        (error) => {
          console.log("GPS permission denied:", error);
        }
      );
    }
  }, []);

  const handleGetGPS = async () => {
    setIsGpsLoading(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setGpsLocation({
            lat: latitude,
            lng: longitude,
            address: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
          });
          setGpsEnabled(true);
          setIsGpsLoading(false);
        },
        (error) => {
          alert("Erreur: Veuillez activer la géolocalisation");
          setIsGpsLoading(false);
        }
      );
    }
  };

  const handleSubmitOrder = () => {
    if (!productName.trim()) {
      alert("Veuillez entrer le nom du produit");
      return;
    }

    if (!deliveryAddress.trim() && !gpsLocation) {
      alert("Veuillez entrer une adresse ou partager votre position GPS");
      return;
    }

    // Simulate order submission
    setOrderSubmitted(true);

    // Auto-redirect after 3 seconds
    setTimeout(() => {
      setLocation("/history");
    }, 3000);
  };

  if (orderSubmitted) {
    return (
      <div className="min-h-screen bg-[#F9F9F9] flex items-center justify-center">
        <div className="bg-white rounded-2xl p-12 text-center max-w-md shadow-lg">
          <div className="mb-6 flex justify-center">
            <div className="relative">
              <div className="w-20 h-20 bg-[#009460]/10 rounded-full flex items-center justify-center animate-pulse">
                <CheckCircle className="w-12 h-12 text-[#009460]" />
              </div>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-[#1A1A1A] mb-2">Commande Validée!</h2>
          <p className="text-[#666666] mb-6">
            Votre commande a été envoyée au livreur. Vous allez être redirigé vers l'historique...
          </p>
          <div className="space-y-2">
            <p className="text-sm text-[#009460] font-semibold">✅ Produit: {productName}</p>
            <p className="text-sm text-[#009460] font-semibold">
              ✅ Transport: {transportType === "bike" ? "🚲 Vélo" : "🏍 Moto"}
            </p>
            <p className="text-sm text-[#009460] font-semibold">
              ✅ Contact: {contactMethod === "whatsapp" ? "WhatsApp" : contactMethod === "sms" ? "SMS" : "Appel"}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
          </button>
          <h1 className="text-2xl font-bold text-[#1A1A1A]">Commande Rapide</h1>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="bg-white border-b border-[#E0E0E0]">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all ${
                    s <= step
                      ? "bg-[#E3001C] text-white"
                      : "bg-[#E0E0E0] text-[#666666]"
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div
                    className={`flex-1 h-1 mx-2 transition-all ${
                      s < step ? "bg-[#E3001C]" : "bg-[#E0E0E0]"
                    }`}
                  ></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8">
        {step === 1 && (
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-[#1A1A1A]">Qu'est-ce que vous voulez envoyer?</h2>

            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
                Nom du produit ou description
              </label>
              <input
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="Ex: 1 pizza, 2 jus, 1 pain"
                className="w-full px-4 py-3 border border-[#E0E0E0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
                Notes spéciales (optionnel)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ex: pas trop épicé, livrer à 14h, etc."
                rows={4}
                className="w-full px-4 py-3 border border-[#E0E0E0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent resize-none"
              />
            </div>

            <Button
              onClick={() => setStep(2)}
              className="w-full bg-[#E3001C] hover:bg-[#C70016] text-white font-bold py-4 text-lg rounded-xl"
            >
              Continuer
            </Button>
          </div>
        )}

        {step === 2 && (
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-[#1A1A1A]">Où livrer?</h2>

            {/* GPS Option */}
            <div className="bg-[#009460]/10 border border-[#009460] rounded-2xl p-6">
              <h3 className="font-bold text-[#1A1A1A] mb-4 flex items-center gap-2">
                <Navigation className="w-5 h-5 text-[#009460]" />
                Partager votre position GPS
              </h3>

              {gpsLocation ? (
                <div className="bg-white rounded-lg p-4 mb-4">
                  <p className="text-sm text-[#666666] mb-2">Position détectée:</p>
                  <p className="font-semibold text-[#1A1A1A]">{gpsLocation.address}</p>
                  <a
                    href={`https://maps.google.com/?q=${gpsLocation.lat},${gpsLocation.lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#E3001C] hover:underline mt-2 inline-block"
                  >
                    Voir sur Google Maps
                  </a>
                </div>
              ) : (
                <Button
                  onClick={handleGetGPS}
                  disabled={isGpsLoading}
                  className="w-full bg-[#009460] hover:bg-[#007A4A] text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2"
                >
                  <MapPin className="w-5 h-5" />
                  {isGpsLoading ? "Localisation..." : "Utiliser ma position"}
                </Button>
              )}
            </div>

            {/* Manual Address Option */}
            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
                Ou entrez votre adresse manuellement
              </label>
              <input
                type="text"
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                placeholder="Ex: Quartier Dixinn, rue de la Paix, près du marché"
                className="w-full px-4 py-3 border border-[#E0E0E0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent"
              />
            </div>

            {/* Transport Type */}
            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
                Moyen de transport
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setTransportType("bike")}
                  className={`p-4 rounded-xl border-2 transition-all font-semibold ${
                    transportType === "bike"
                      ? "border-[#009460] bg-[#009460]/10 text-[#009460]"
                      : "border-[#E0E0E0] text-[#666666] hover:border-[#009460]"
                  }`}
                >
                  🚲 Vélo
                </button>
                <button
                  onClick={() => setTransportType("motorcycle")}
                  className={`p-4 rounded-xl border-2 transition-all font-semibold ${
                    transportType === "motorcycle"
                      ? "border-[#E3001C] bg-[#E3001C]/10 text-[#E3001C]"
                      : "border-[#E0E0E0] text-[#666666] hover:border-[#E3001C]"
                  }`}
                >
                  🏍 Moto
                </button>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setStep(1)}
                variant="outline"
                className="flex-1 border-[#E0E0E0] hover:bg-[#F5F5F5] text-[#1A1A1A] font-bold py-4 rounded-xl"
              >
                Retour
              </Button>
              <Button
                onClick={() => setStep(3)}
                className="flex-1 bg-[#E3001C] hover:bg-[#C70016] text-white font-bold py-4 rounded-xl"
              >
                Continuer
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-[#1A1A1A]">Comment vous contacter?</h2>

            <div className="space-y-3">
              <button
                onClick={() => setContactMethod("whatsapp")}
                className={`w-full p-4 rounded-xl border-2 transition-all text-left font-semibold ${
                  contactMethod === "whatsapp"
                    ? "border-[#009460] bg-[#009460]/10 text-[#009460]"
                    : "border-[#E0E0E0] text-[#666666] hover:border-[#009460]"
                }`}
              >
                💬 WhatsApp
              </button>
              <button
                onClick={() => setContactMethod("sms")}
                className={`w-full p-4 rounded-xl border-2 transition-all text-left font-semibold ${
                  contactMethod === "sms"
                    ? "border-[#FCD116] bg-[#FCD116]/10 text-[#FCD116]"
                    : "border-[#E0E0E0] text-[#666666] hover:border-[#FCD116]"
                }`}
              >
                📱 SMS
              </button>
              <button
                onClick={() => setContactMethod("call")}
                className={`w-full p-4 rounded-xl border-2 transition-all text-left font-semibold ${
                  contactMethod === "call"
                    ? "border-[#E3001C] bg-[#E3001C]/10 text-[#E3001C]"
                    : "border-[#E0E0E0] text-[#666666] hover:border-[#E3001C]"
                }`}
              >
                ☎️ Appel Téléphonique
              </button>
            </div>

            {/* Summary */}
            <div className="bg-white rounded-2xl p-6 border border-[#E0E0E0]">
              <h3 className="font-bold text-[#1A1A1A] mb-4">Résumé de votre commande</h3>
              <div className="space-y-2 text-sm">
                <p>
                  <span className="text-[#666666]">Produit:</span>{" "}
                  <span className="font-semibold text-[#1A1A1A]">{productName}</span>
                </p>
                <p>
                  <span className="text-[#666666]">Adresse:</span>{" "}
                  <span className="font-semibold text-[#1A1A1A]">
                    {gpsLocation ? gpsLocation.address : deliveryAddress}
                  </span>
                </p>
                <p>
                  <span className="text-[#666666]">Transport:</span>{" "}
                  <span className="font-semibold text-[#1A1A1A]">
                    {transportType === "bike" ? "🚲 Vélo" : "🏍 Moto"}
                  </span>
                </p>
                <p>
                  <span className="text-[#666666]">Contact:</span>{" "}
                  <span className="font-semibold text-[#1A1A1A]">
                    {contactMethod === "whatsapp" ? "💬 WhatsApp" : contactMethod === "sms" ? "📱 SMS" : "☎️ Appel"}
                  </span>
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setStep(2)}
                variant="outline"
                className="flex-1 border-[#E0E0E0] hover:bg-[#F5F5F5] text-[#1A1A1A] font-bold py-4 rounded-xl"
              >
                Retour
              </Button>
              <Button
                onClick={handleSubmitOrder}
                className="flex-1 bg-[#E3001C] hover:bg-[#C70016] text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2"
              >
                <Zap className="w-5 h-5" />
                Valider la Commande
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
