import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  phone: varchar("phone", { length: 20 }).notNull().unique(),
  address: text("address"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["client", "driver", "admin"]).default("client").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Drivers table - Extended information for delivery personnel
export const drivers = mysqlTable("drivers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  transportType: mysqlEnum("transportType", ["bike", "motorcycle"]).notNull(),
  isActive: int("isActive").default(1).notNull(),
  totalCommission: int("totalCommission").default(0).notNull(),
  completedDeliveries: int("completedDeliveries").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Driver = typeof drivers.$inferSelect;
export type InsertDriver = typeof drivers.$inferInsert;

// Orders table - Main delivery orders
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  clientId: int("clientId").notNull(),
  driverId: int("driverId"),
  productName: text("productName").notNull(),
  deliveryAddress: text("deliveryAddress").notNull(),
  transportType: mysqlEnum("transportType", ["bike", "motorcycle"]).notNull(),
  specialInstructions: text("specialInstructions"),
  status: mysqlEnum("status", ["pending", "accepted", "in_transit", "delivered", "cancelled"]).default("pending").notNull(),
  clientLatitude: varchar("clientLatitude", { length: 20 }),
  clientLongitude: varchar("clientLongitude", { length: 20 }),
  deliveryLatitude: varchar("deliveryLatitude", { length: 20 }),
  deliveryLongitude: varchar("deliveryLongitude", { length: 20 }),
  distanceKm: varchar("distanceKm", { length: 10 }),
  deliveryFee: int("deliveryFee"),
  driverCommission: int("driverCommission"),
  paymentMethod: mysqlEnum("paymentMethod", ["cash"]).default("cash").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "completed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// Notifications table - For tracking notification history
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  orderId: int("orderId"),
  type: mysqlEnum("type", ["order_sent", "driver_accepted", "in_transit", "delivered", "cancelled"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: int("isRead").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;