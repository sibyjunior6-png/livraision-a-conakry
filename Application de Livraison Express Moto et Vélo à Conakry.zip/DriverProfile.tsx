import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, MapPin, Star, Bike, Truck, Phone, MessageSquare, Clock } from "lucide-react";

interface Review {
  id: number;
  clientName: string;
  rating: number;
  comment: string;
  date: string;
}

const mockReviews: Review[] = [
  {
    id: 1,
    clientName: "Fatou Diallo",
    rating: 5,
    comment: "Très rapide et courtois! Livraison impeccable.",
    date: "2024-11-03",
  },
  {
    id: 2,
    clientName: "Ousmane Bah",
    rating: 5,
    comment: "Excellent service. Recommandé!",
    date: "2024-11-02",
  },
  {
    id: 3,
    clientName: "Aïssatou Sy",
    rating: 4,
    comment: "Bon livreur, un peu en retard mais très sympa.",
    date: "2024-11-01",
  },
];

export default function DriverProfile() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"info" | "reviews">("info");

  const driver = {
    id: 1,
    name: "Sory Diallo",
    transportType: "bike" as const,
    rating: 4.9,
    reviews: 156,
    distance: 0.8,
    pricePerKm: 5,
    zone: "Matoto",
    avatar: "👨‍🚴",
    isOnline: true,
    completedDeliveries: 428,
    responseTime: "2 min",
    acceptanceRate: "98%",
    bio: "Livreur professionnel avec 3 ans d'expérience. Rapide, fiable et courtois.",
    availability: "Lun-Dim 8h-20h",
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => setLocation("/available-drivers")}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
          </button>
          <h1 className="text-2xl font-bold text-[#1A1A1A]">Profil Livreur</h1>
        </div>
      </header>

      {/* Profile Header */}
      <div className="bg-white border-b border-[#E0E0E0]">
        <div className="container py-8">
          <div className="flex items-start gap-6 mb-6">
            <div className="text-8xl">{driver.avatar}</div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-3xl font-bold text-[#1A1A1A]">{driver.name}</h2>
                {driver.isOnline && (
                  <div className="flex items-center gap-1 bg-[#009460]/10 px-3 py-1 rounded-full">
                    <div className="w-2 h-2 bg-[#009460] rounded-full"></div>
                    <span className="text-xs font-semibold text-[#009460]">En ligne</span>
                  </div>
                )}
              </div>

              {/* Rating */}
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(driver.rating)
                          ? "text-[#FCD116] fill-[#FCD116]"
                          : "text-[#E0E0E0]"
                      }`}
                    />
                  ))}
                </div>
                <span className="font-bold text-[#1A1A1A]">{driver.rating}</span>
                <span className="text-sm text-[#666666]">({driver.reviews} avis)</span>
              </div>

              {/* Bio */}
              <p className="text-[#666666]">{driver.bio}</p>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#F9F9F9] rounded-lg p-4">
              <p className="text-xs text-[#666666] mb-1">Livraisons</p>
              <p className="text-2xl font-bold text-[#E3001C]">{driver.completedDeliveries}</p>
            </div>
            <div className="bg-[#F9F9F9] rounded-lg p-4">
              <p className="text-xs text-[#666666] mb-1">Temps de réponse</p>
              <p className="text-2xl font-bold text-[#009460]">{driver.responseTime}</p>
            </div>
            <div className="bg-[#F9F9F9] rounded-lg p-4">
              <p className="text-xs text-[#666666] mb-1">Taux d'acceptation</p>
              <p className="text-2xl font-bold text-[#FCD116]">{driver.acceptanceRate}</p>
            </div>
            <div className="bg-[#F9F9F9] rounded-lg p-4">
              <p className="text-xs text-[#666666] mb-1">Tarif</p>
              <p className="text-2xl font-bold text-[#1A1A1A]">{driver.pricePerKm} GNF/km</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-[#E0E0E0] sticky top-16 z-40">
        <div className="container flex gap-8">
          <button
            onClick={() => setActiveTab("info")}
            className={`py-4 font-semibold border-b-2 transition-colors ${
              activeTab === "info"
                ? "border-[#E3001C] text-[#E3001C]"
                : "border-transparent text-[#666666]"
            }`}
          >
            Informations
          </button>
          <button
            onClick={() => setActiveTab("reviews")}
            className={`py-4 font-semibold border-b-2 transition-colors ${
              activeTab === "reviews"
                ? "border-[#E3001C] text-[#E3001C]"
                : "border-transparent text-[#666666]"
            }`}
          >
            Avis ({driver.reviews})
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8">
        {activeTab === "info" && (
          <div className="space-y-6 max-w-2xl">
            {/* Zone */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h3 className="font-bold text-[#1A1A1A] mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#E3001C]" />
                Zone de livraison
              </h3>
              <p className="text-[#666666]">{driver.zone}</p>
            </div>

            {/* Transport */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h3 className="font-bold text-[#1A1A1A] mb-4 flex items-center gap-2">
                {driver.transportType === "bike" ? (
                  <Bike className="w-5 h-5 text-[#009460]" />
                ) : (
                  <Truck className="w-5 h-5 text-[#E3001C]" />
                )}
                Moyen de transport
              </h3>
              <p className="text-[#666666]">
                {driver.transportType === "bike" ? "Vélo" : "Moto"}
              </p>
            </div>

            {/* Availability */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h3 className="font-bold text-[#1A1A1A] mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-[#FCD116]" />
                Disponibilité
              </h3>
              <p className="text-[#666666]">{driver.availability}</p>
            </div>

            {/* Contact */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h3 className="font-bold text-[#1A1A1A] mb-4">Contacter</h3>
              <div className="flex gap-3">
                <Button className="flex-1 bg-[#009460] hover:bg-[#007A4A] text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  WhatsApp
                </Button>
                <Button className="flex-1 bg-[#E3001C] hover:bg-[#C70016] text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2">
                  <Phone className="w-5 h-5" />
                  Appeler
                </Button>
              </div>
            </div>
          </div>
        )}

        {activeTab === "reviews" && (
          <div className="space-y-4 max-w-2xl">
            {mockReviews.map((review) => (
              <div key={review.id} className="bg-white rounded-2xl p-6 shadow-sm">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-bold text-[#1A1A1A]">{review.clientName}</h4>
                    <p className="text-xs text-[#666666]">{review.date}</p>
                  </div>
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < review.rating
                            ? "text-[#FCD116] fill-[#FCD116]"
                            : "text-[#E0E0E0]"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-[#666666]">{review.comment}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Order Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#E0E0E0] p-4">
        <div className="container">
          <Button className="w-full bg-[#E3001C] hover:bg-[#C70016] text-white font-bold py-4 text-lg rounded-xl">
            Commander avec {driver.name}
          </Button>
        </div>
      </div>
    </div>
  );
}
