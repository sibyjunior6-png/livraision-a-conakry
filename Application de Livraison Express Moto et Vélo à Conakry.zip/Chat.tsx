import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Send, Phone, MapPin, Navigation, Clock } from "lucide-react";

interface Message {
  id: string;
  sender: string;
  senderRole: "client" | "driver";
  content: string;
  timestamp: Date;
  type: "text" | "location";
  location?: { lat: number; lng: number; address: string };
}

interface UserLocation {
  lat: number;
  lng: number;
  address: string;
  timestamp: Date;
}

export default function Chat() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "Livreur",
      senderRole: "driver",
      content: "Bonjour! Je suis en route pour votre livraison 🚴",
      timestamp: new Date(Date.now() - 5 * 60000),
      type: "text",
    },
    {
      id: "2",
      sender: "Vous",
      senderRole: "client",
      content: "Merci! Vous êtes loin?",
      timestamp: new Date(Date.now() - 3 * 60000),
      type: "text",
    },
    {
      id: "3",
      sender: "Livreur",
      senderRole: "driver",
      content: "À environ 5 minutes. Je suis près du marché Kindia",
      timestamp: new Date(Date.now() - 1 * 60000),
      type: "text",
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [clientLocation, setClientLocation] = useState<UserLocation>({
    lat: 9.5412,
    lng: -13.6929,
    address: "Dixinn, Conakry",
    timestamp: new Date(),
  });
  const [driverLocation, setDriverLocation] = useState<UserLocation>({
    lat: 9.5412,
    lng: -13.6929,
    address: "En route vers Dixinn",
    timestamp: new Date(),
  });
  const [showLocationShare, setShowLocationShare] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Simulate real-time GPS updates every 2 seconds
  useEffect(() => {
    if (!isSharing) return;

    const interval = setInterval(() => {
      setClientLocation((prev) => ({
        ...prev,
        lat: prev.lat + (Math.random() - 0.5) * 0.0001,
        lng: prev.lng + (Math.random() - 0.5) * 0.0001,
        timestamp: new Date(),
      }));

      setDriverLocation((prev) => ({
        ...prev,
        lat: prev.lat + (Math.random() - 0.5) * 0.0001,
        lng: prev.lng + (Math.random() - 0.5) * 0.0001,
        timestamp: new Date(),
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, [isSharing]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: "Vous",
      senderRole: "client",
      content: inputMessage,
      timestamp: new Date(),
      type: "text",
    };

    setMessages([...messages, newMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate driver response after 2 seconds
    setTimeout(() => {
      const responses = [
        "D'accord! 👍",
        "Pas de problème!",
        "Je suis presque là!",
        "Merci pour votre patience",
      ];
      const randomResponse =
        responses[Math.floor(Math.random() * responses.length)];

      const driverMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "Livreur",
        senderRole: "driver",
        content: randomResponse,
        timestamp: new Date(),
        type: "text",
      };

      setMessages((prev) => [...prev, driverMessage]);
      setIsTyping(false);
    }, 2000);
  };

  const handleShareLocation = () => {
    setIsSharing(true);
    setShowLocationShare(false);

    // Add location message
    const locationMessage: Message = {
      id: Date.now().toString(),
      sender: "Vous",
      senderRole: "client",
      content: "📍 Position partagée",
      timestamp: new Date(),
      type: "location",
      location: clientLocation,
    };

    setMessages([...messages, locationMessage]);

    // Simulate driver sharing location
    setTimeout(() => {
      const driverLocationMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "Livreur",
        senderRole: "driver",
        content: "📍 Position partagée",
        timestamp: new Date(),
        type: "location",
        location: driverLocation,
      };

      setMessages((prev) => [...prev, driverLocationMessage]);
    }, 1000);
  };

  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371; // Rayon de la Terre en km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return (R * c).toFixed(2);
  };

  const distance = calculateDistance(
    clientLocation.lat,
    clientLocation.lng,
    driverLocation.lat,
    driverLocation.lng
  );

  return (
    <div className="min-h-screen bg-[#F9F9F9] flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/")}
              className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
            </button>
            <div>
              <h1 className="text-lg font-bold text-[#1A1A1A]">Livreur</h1>
              <p className="text-xs text-[#009460] font-semibold">
                🟢 En ligne • {distance} km
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors">
              <Phone className="w-5 h-5 text-[#E3001C]" />
            </button>
            <button className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors">
              <MapPin className="w-5 h-5 text-[#E3001C]" />
            </button>
          </div>
        </div>
      </header>

      {/* GPS Status Bar */}
      {isSharing && (
        <div className="bg-[#009460]/10 border-b border-[#009460] px-4 py-3">
          <div className="container flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Navigation className="w-5 h-5 text-[#009460] animate-pulse" />
              <span className="text-sm font-semibold text-[#009460]">
                Partage GPS en direct activé
              </span>
            </div>
            <button
              onClick={() => setIsSharing(false)}
              className="text-xs bg-[#009460] hover:bg-[#007A4A] text-white px-3 py-1 rounded-full transition-colors"
            >
              Arrêter
            </button>
          </div>
        </div>
      )}

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.senderRole === "client" ? "justify-end" : "justify-start"}`}
          >
            {message.type === "location" ? (
              <div
                className={`max-w-xs px-4 py-3 rounded-2xl ${
                  message.senderRole === "client"
                    ? "bg-[#E3001C] text-white rounded-br-none"
                    : "bg-white text-[#1A1A1A] border border-[#E0E0E0] rounded-bl-none"
                }`}
              >
                <div className="bg-white/20 rounded-lg p-3 mb-2">
                  <p className="text-sm font-semibold mb-2">📍 Position partagée</p>
                  <p className="text-xs opacity-90">{message.location?.address}</p>
                  <p className="text-xs opacity-75 mt-1">
                    {message.location?.lat.toFixed(4)}, {message.location?.lng.toFixed(4)}
                  </p>
                </div>
                <a
                  href={`https://maps.google.com/?q=${message.location?.lat},${message.location?.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs underline block"
                >
                  Ouvrir sur Google Maps
                </a>
                <p
                  className={`text-xs mt-2 ${
                    message.senderRole === "client"
                      ? "text-[#FCD116]"
                      : "text-[#666666]"
                  }`}
                >
                  {message.timestamp.toLocaleTimeString("fr-FR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            ) : (
              <div
                className={`max-w-xs px-4 py-3 rounded-2xl ${
                  message.senderRole === "client"
                    ? "bg-[#E3001C] text-white rounded-br-none"
                    : "bg-white text-[#1A1A1A] border border-[#E0E0E0] rounded-bl-none"
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p
                  className={`text-xs mt-1 ${
                    message.senderRole === "client"
                      ? "text-[#FCD116]"
                      : "text-[#666666]"
                  }`}
                >
                  {message.timestamp.toLocaleTimeString("fr-FR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            )}
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white text-[#1A1A1A] border border-[#E0E0E0] px-4 py-3 rounded-2xl rounded-bl-none">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-[#666666] rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-[#666666] rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                <div className="w-2 h-2 bg-[#666666] rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-[#E0E0E0] p-4 sticky bottom-0">
        <form onSubmit={handleSendMessage} className="flex gap-3 mb-3">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Votre message..."
            className="flex-1 px-4 py-3 border border-[#E0E0E0] rounded-full focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent"
          />
          <button
            type="submit"
            className="bg-[#E3001C] hover:bg-[#C70016] text-white p-3 rounded-full transition-colors flex items-center justify-center"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>

        {/* Quick Actions */}
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setShowLocationShare(!showLocationShare)}
            className="text-xs bg-[#F5F5F5] hover:bg-[#E0E0E0] text-[#1A1A1A] py-2 px-3 rounded-lg transition-colors flex items-center justify-center gap-1"
          >
            <MapPin className="w-4 h-4" />
            Partager position
          </button>
          <button className="text-xs bg-[#F5F5F5] hover:bg-[#E0E0E0] text-[#1A1A1A] py-2 px-3 rounded-lg transition-colors">
            ⏱️ Estimer arrivée
          </button>
          <button className="text-xs bg-[#F5F5F5] hover:bg-[#E0E0E0] text-[#1A1A1A] py-2 px-3 rounded-lg transition-colors">
            ☎️ Appeler
          </button>
        </div>

        {/* Location Share Confirmation */}
        {showLocationShare && (
          <div className="mt-3 bg-[#FCD116]/10 border border-[#FCD116] rounded-lg p-3">
            <p className="text-sm font-semibold text-[#1A1A1A] mb-2">
              Partager votre position en temps réel?
            </p>
            <p className="text-xs text-[#666666] mb-3">
              Votre position sera mise à jour toutes les 2 secondes
            </p>
            <div className="flex gap-2">
              <Button
                onClick={handleShareLocation}
                className="flex-1 bg-[#009460] hover:bg-[#007A4A] text-white font-semibold py-2 rounded-lg text-sm"
              >
                Partager
              </Button>
              <Button
                onClick={() => setShowLocationShare(false)}
                variant="outline"
                className="flex-1 border-[#E0E0E0] hover:bg-[#F5F5F5] text-[#1A1A1A] font-semibold py-2 rounded-lg text-sm"
              >
                Annuler
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
