import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Truck, Bike, MapPin, Phone, Zap } from "lucide-react";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();

  const handleOrderClick = () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
    } else {
      setLocation("/order");
    }
  };

  const handleHistoryClick = () => {
    if (isAuthenticated) {
      setLocation("/history");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F9F9F9] to-[#FFFFFF]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex justify-between items-center py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#E3001C] to-[#009460] rounded-lg flex items-center justify-center text-white font-bold">
              LG
            </div>
            <h1 className="text-xl font-bold text-[#1A1A1A]">{APP_TITLE}</h1>
          </div>
          {isAuthenticated && (
            <div className="flex items-center gap-3">
              <span className="text-sm text-[#666666]">{user?.name || "User"}</span>
              {user?.role === "admin" && (
                <Button
                  onClick={() => setLocation("/admin")}
                  size="sm"
                  className="bg-[#E3001C] hover:bg-[#C70016] text-white"
                >
                  Admin
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"