# Architecture et Spécifications Techniques du Projet "LivraisonGN Pro"

## 1. Objectif du Projet
Créer une Application Web Progressive (PWA) moderne, légère et rapide pour un service de livraison express à Conakry, Guinée. L'application doit intégrer des fonctionnalités pour les clients, les livreurs et l'administration, en mettant l'accent sur l'expérience utilisateur (UI/UX) et l'intégration des fonctionnalités natives (GPS, notifications, communication).

## 2. Architecture Technique

| Composant | Technologie / Approche | Justification |
| :--- | :--- | :--- |
| **Type d'Application** | Application Web Progressive (PWA) | Répond au besoin de compatibilité "Manus mobile + Manus ordinateur" et permet une utilisation hors ligne après la première ouverture. |
| **Frontend (Client/Livreur/Admin)** | Framework Web Moderne (React/Vue/Svelte) | Permet de créer une interface utilisateur riche, fluide, avec des animations modernes et des transitions rapides, conformément aux exigences "Figma style". |
| **Backend (API/Logique Métier)** | Framework Full-Stack (Node.js/Python) | Nécessaire pour gérer l'authentification, la logique de commande, le calcul des commissions, et l'interface d'administration. |
| **Base de Données** | Base de données relationnelle (PostgreSQL/SQLite) | Stockage fiable des utilisateurs (clients, livreurs, admins), des commandes, des historiques et des statistiques. |
| **Hébergement** | Environnement Manus (Simulé) | Déploiement optimisé pour la compatibilité Manus. |

## 3. Modèle de Données (Entités Principales)

| Entité | Champs Clés | Description |
| :--- | :--- | :--- |
| **Utilisateur** | `id`, `nom`, `telephone` (authentification), `adresse`, `role` (Client/Livreur/Admin) | Stockage des informations d'inscription rapide. |
| **Livreur** | `id_livreur`, `commission_totale`, `moyen_transport` (Vélo/Moto), `statut` (Actif/Inactif) | Informations spécifiques aux livreurs. |
| **Commande** | `id`, `id_client`, `nom_produit`, `adresse_livraison`, `moyen_transport`, `instructions`, `statut` (En attente/Acceptée/En route/Livrée), `date_commande` | Détails de la commande. |
| **Transaction** | `id`, `id_commande`, `distance_km`, `frais_livraison`, `commission_livreur` (10%), `montant_total` | Données financières et de calcul. |

## 4. Logique Métier Clé

### A. Authentification
*   **Méthode :** Par numéro de téléphone uniquement (sans Gmail).
*   **Processus :** Envoi d'un code de vérification par SMS (simulé via API Manus) pour valider le numéro.

### B. Calcul des Frais de Livraison
*   **Principe :** Calculé par la distance GPS.
*   **Règle :** **1 km = 5 GNF** (Unité monétaire à confirmer, mais la logique est de 5 unités par km).
*   **Formule :** `Frais de Livraison = Distance (km) * 5`
*   **Implémentation :** Utilisation de l'API de géolocalisation Manus pour déterminer la distance entre le point de collecte (présumé fixe ou déterminé par le livreur) et l'adresse de livraison.

### C. Commissions
*   **Règle :** **10 %** du frais de livraison.
*   **Formule :** `Commission = Frais de Livraison * 0.10`
*   **Affichage :** Affiché dans le tableau de bord du livreur.

### D. Communication (Envoi Automatique de la Commande)
L'application doit simuler l'envoi de la commande via trois canaux après validation :
1.  **WhatsApp :** Utilisation de l'API Manus pour l'intégration WhatsApp.
2.  **SMS (Texto) :** Utilisation de l'API Manus pour l'envoi de SMS.
3.  **Appel Téléphonique :** Utilisation de l'API Manus pour simuler l'appel.

## 5. Fonctionnalités Spécifiques

| Fonctionnalité | Description Technique |
| :--- | :--- |
| **Partage de position GPS** | Utilisation de l'API de géolocalisation Manus en temps réel (WebSockets ou polling fréquent) pour la mise à jour client ↔ livreur. |
| **Notifications Locales** | Utilisation de l'API de Notifications Manus (Service Workers pour PWA) pour les alertes d'état de commande. |
| **Interface Livreur** | Vue des commandes disponibles (filtrées par zone/distance), bouton d'action "Accepter la livraison" qui change le statut de la commande. |
| **Interface Admin** | Tableau de bord CRUD (Create, Read, Update, Delete) pour la gestion des utilisateurs, des commandes et des statistiques de base. |

## 6. Design et UI/UX
*   **Palette de Couleurs :** Rouge 🟥, Jaune 🟨, Vert 🟩 (Style guinéen).
*   **Style :** Écrans arrondis, fond clair, icônes minimalistes.
*   **Animations :** Transitions fluides, effet de chargement inspiré d'Uber Eats, animation de livreur sur la carte.
*   **Boutons Flottants :** "Commander maintenant" et "Appeler livreur" (avec le numéro fixe : +224 612 15 87 95).
