import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, TrendingUp, Users, Truck, DollarSign } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: allOrders = [] } = trpc.orders.getAvailable.useQuery();

  const totalOrders = allOrders.length;
  const totalRevenue = allOrders.reduce((sum, order: any) => sum + (order.deliveryFee || 0), 0);
  const completedOrders = allOrders.filter((o: any) => o.status === "delivered").length;

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/")}
              className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
            </button>
            <h1 className="text-2xl font-bold text-[#1A1A1A]">Tableau de Bord Admin</h1>
          </div>
          <div className="text-right">
            <p className="text-sm text-[#666666]">{user?.name}</p>
            <p className="text-xs text-[#E3001C] font-semibold">Administrateur</p>
          </div>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="container py-8">
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm border-l-4 border-[#E3001C]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#666666] mb-1">Commandes Totales</p>
                <p className="text-3xl font-bold text-[#1A1A1A]">{totalOrders}</p>
              </div>
              <Truck className="w-12 h-12 text-[#E3001C] opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border-l-4 border-[#009460]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#666666] mb-1">Commandes Complétées</p>
                <p className="text-3xl font-bold text-[#1A1A1A]">{completedOrders}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-[#009460] opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border-l-4 border-[#FCD116]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#666666] mb-1">Revenu Total</p>
                <p className="text-3xl font-bold text-[#1A1A1A]">{totalRevenue} GNF</p>
              </div>
              <DollarSign className="w-12 h-12 text-[#FCD116] opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border-l-4 border-[#E3001C]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#666666] mb-1">Livreurs Actifs</p>
                <p className="text-3xl font-bold text-[#1A1A1A]">12</p>
              </div>
              <Users className="w-12 h-12 text-[#E3001C] opacity-20" />
            </div>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-[#E0E0E0]">
            <h2 className="text-xl font-bold text-[#1A1A1A]">Commandes Récentes</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#F9F9F9] border-b border-[#E0E0E0]">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-[#666666]">
                    Produit
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-[#666666]">
                    Adresse
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-[#666666]">
                    Transport
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-[#666666]">
                    Statut
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-[#666666]">
                    Frais
                  </th>
                </tr>
              </thead>
              <tbody>
                {allOrders.slice(0, 5).map((order: any) => (
                  <tr key={order.id} className="border-b border-[#E0E0E0] hover:bg-[#F9F9F9]">
                    <td className="px-6 py-4 text-sm font-semibold text-[#1A1A1A]">
                      {order.productName}
                    </td>
                    <td className="px-6 py-4 text-sm text-[#666666]">{order.deliveryAddress}</td>
                    <td className="px-6 py-4 text-sm text-[#666666]">
                      {order.transportType === "bike" ? "🚲 Vélo" : "🏍 Moto"}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          order.status === "delivered"
                            ? "bg-[#009460]/10 text-[#009460]"
                            : "bg-[#FCD116]/10 text-[#FCD116]"
                        }`}
                      >
                        {order.status === "delivered" ? "Livrée" : "En attente"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right text-sm font-bold text-[#E3001C]">
                      {order.deliveryFee} GNF
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
