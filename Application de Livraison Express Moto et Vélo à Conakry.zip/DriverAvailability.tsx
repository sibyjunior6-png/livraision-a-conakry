import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, MapPin, Clock, Zap, MessageSquare } from "lucide-react";

interface Availability {
  id: string;
  zone: string;
  status: "available" | "busy" | "offline";
  message: string;
  timestamp: Date;
}

export default function DriverAvailability() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [isOnline, setIsOnline] = useState(true);
  const [selectedZone, setSelectedZone] = useState("Dixinn");
  const [customMessage, setCustomMessage] = useState("");
  const [availabilities, setAvailabilities] = useState<Availability[]>([
    {
      id: "1",
      zone: "Dixinn",
      status: "available",
      message: "Disponible à Dixinn maintenant",
      timestamp: new Date(Date.now() - 5 * 60000),
    },
    {
      id: "2",
      zone: "Kaloum",
      status: "busy",
      message: "En livraison à Kaloum",
      timestamp: new Date(Date.now() - 15 * 60000),
    },
  ]);

  const zones = ["Dixinn", "Kaloum", "Matoto", "Ratoma", "Kindia", "Coyah"];

  const handlePostAvailability = () => {
    if (!customMessage.trim()) return;

    const newAvailability: Availability = {
      id: Date.now().toString(),
      zone: selectedZone,
      status: "available",
      message: customMessage,
      timestamp: new Date(),
    };

    setAvailabilities([newAvailability, ...availabilities]);
    setCustomMessage("");
  };

  const handleDeleteAvailability = (id: string) => {
    setAvailabilities(availabilities.filter((a) => a.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-[#009460]/10 text-[#009460] border-[#009460]";
      case "busy":
        return "bg-[#FCD116]/10 text-[#FCD116] border-[#FCD116]";
      case "offline":
        return "bg-[#E0E0E0]/10 text-[#666666] border-[#E0E0E0]";
      default:
        return "";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "available":
        return "Disponible";
      case "busy":
        return "Occupé";
      case "offline":
        return "Hors ligne";
      default:
        return "";
    }
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/driver")}
              className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
            </button>
            <h1 className="text-2xl font-bold text-[#1A1A1A]">Mes Disponibilités</h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-[#666666]">Statut:</span>
            <button
              onClick={() => setIsOnline(!isOnline)}
              className={`px-4 py-2 rounded-full font-semibold transition-all ${
                isOnline
                  ? "bg-[#009460] text-white"
                  : "bg-[#E0E0E0] text-[#666666]"
              }`}
            >
              {isOnline ? "🟢 En ligne" : "⚫ Hors ligne"}
            </button>
          </div>
        </div>
      </header>

      {/* Post Availability Form */}
      <div className="container py-8">
        <div className="bg-white rounded-2xl p-6 shadow-sm mb-8">
          <h2 className="text-xl font-bold text-[#1A1A1A] mb-6 flex items-center gap-2">
            <Zap className="w-6 h-6 text-[#FCD116]" />
            Poster une disponibilité
          </h2>

          {/* Zone Selection */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
              Zone de livraison
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {zones.map((zone) => (
                <button
                  key={zone}
                  onClick={() => setSelectedZone(zone)}
                  className={`p-3 rounded-lg border-2 transition-all font-semibold ${
                    selectedZone === zone
                      ? "border-[#E3001C] bg-[#E3001C]/10 text-[#E3001C]"
                      : "border-[#E0E0E0] text-[#666666] hover:border-[#E3001C]"
                  }`}
                >
                  <MapPin className="w-4 h-4 inline mr-1" />
                  {zone}
                </button>
              ))}
            </div>
          </div>

          {/* Message Input */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
              Message de disponibilité
            </label>
            <textarea
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder="Ex: Disponible à Dixinn maintenant&#10;ou: En livraison, libre dans 30 min"
              rows={3}
              className="w-full px-4 py-3 border border-[#E0E0E0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent resize-none"
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={handlePostAvailability}
            disabled={!customMessage.trim() || !isOnline}
            className="w-full bg-[#E3001C] hover:bg-[#C70016] text-white font-bold py-4 text-lg rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Poster la disponibilité
          </Button>
        </div>

        {/* Availabilities List */}
        <div>
          <h2 className="text-xl font-bold text-[#1A1A1A] mb-6">Mes annonces</h2>
          <div className="space-y-4">
            {availabilities.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
                <MessageSquare className="w-16 h-16 text-[#E0E0E0] mx-auto mb-4" />
                <h3 className="text-lg font-bold text-[#1A1A1A] mb-2">Aucune disponibilité</h3>
                <p className="text-[#666666]">
                  Postez une disponibilité pour que les clients vous trouvent
                </p>
              </div>
            ) : (
              availabilities.map((availability) => (
                <div
                  key={availability.id}
                  className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <MapPin className="w-5 h-5 text-[#E3001C]" />
                        <h3 className="text-lg font-bold text-[#1A1A1A]">
                          {availability.zone}
                        </h3>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(
                            availability.status
                          )}`}
                        >
                          {getStatusLabel(availability.status)}
                        </span>
                      </div>
                      <p className="text-[#666666] mb-3">{availability.message}</p>
                      <p className="text-xs text-[#999999] flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {availability.timestamp.toLocaleTimeString("fr-FR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeleteAvailability(availability.id)}
                      className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors text-[#E3001C]"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Quick Actions */}
                  <div className="flex gap-3 pt-4 border-t border-[#E0E0E0]">
                    <Button
                      variant="outline"
                      className="flex-1 border-[#E0E0E0] hover:bg-[#F5F5F5] font-semibold py-2 rounded-lg"
                    >
                      📞 Appels reçus
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1 border-[#E0E0E0] hover:bg-[#F5F5F5] font-semibold py-2 rounded-lg"
                    >
                      💬 Messages
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
