import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Truck, Bike, CheckCircle, Clock, XCircle, MessageSquare } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function History() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { data: orders = [], isLoading } = trpc.orders.getMyOrders.useQuery();

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCircle className="w-5 h-5 text-[#009460]" />;
      case "in_transit":
        return <Truck className="w-5 h-5 text-[#FCD116]" />;
      case "cancelled":
        return <XCircle className="w-5 h-5 text-[#E3001C]" />;
      default:
        return <Clock className="w-5 h-5 text-[#666666]" />;
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: "En attente",
      accepted: "Acceptée",
      in_transit: "En route",
      delivered: "Livrée",
      cancelled: "Annulée",
    };
    return labels[status] || status;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-[#009460]/10 text-[#009460]";
      case "in_transit":
        return "bg-[#FCD116]/10 text-[#FCD116]";
      case "cancelled":
        return "bg-[#E3001C]/10 text-[#E3001C]";
      case "accepted":
        return "bg-[#009460]/10 text-[#009460]";
      default:
        return "bg-[#E0E0E0]/10 text-[#666666]";
    }
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
          </button>
          <h1 className="text-2xl font-bold text-[#1A1A1A]">Historique des Commandes</h1>
        </div>
      </header>

      {/* Content */}
      <div className="container py-8">
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin">
              <Truck className="w-12 h-12 text-[#E3001C]" />
            </div>
            <p className="mt-4 text-[#666666]">Chargement des commandes...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center">
            <Truck className="w-16 h-16 text-[#E0E0E0] mx-auto mb-4" />
            <h2 className="text-xl font-bold text-[#1A1A1A] mb-2">Aucune commande</h2>
            <p className="text-[#666666] mb-6">
              Vous n'avez pas encore passé de commande. Commencez maintenant!
            </p>
            <Button
              onClick={() => setLocation("/order")}
              className="bg-[#E3001C] hover:bg-[#C70016] text-white font-semibold py-3 px-6 rounded-xl"
            >
              Faire une Commande
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order: any) => (
              <div
                key={order.id}
                className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-[#1A1A1A]">{order.productName}</h3>
                    <p className="text-sm text-[#666666] mt-1 flex items-center gap-2">
                      {order.transportType === "bike" ? (
                        <Bike className="w-4 h-4" />
                      ) : (
                        <Truck className="w-4 h-4" />
                      )}
                      {order.transportType === "bike" ? "Vélo" : "Moto"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(order.status)}
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(
                        order.status
                      )}`}
                    >
                      {getStatusLabel(order.status)}
                    </span>
                  </div>
                </div>

                <div className="space-y-3 mb-4 pb-4 border-b border-[#E0E0E0]">
                  <div className="flex items-center gap-2 text-sm text-[#666666]">
                    <span className="font-semibold text-[#1A1A1A] min-w-24">Adresse:</span>
                    <span>{order.deliveryAddress}</span>
                  </div>
                  {order.specialInstructions && (
                    <div className="flex items-start gap-2 text-sm text-[#666666]">
                      <span className="font-semibold text-[#1A1A1A] min-w-24">Instructions:</span>
                      <span>{order.specialInstructions}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-xs text-[#666666]">Frais de livraison</p>
                    <p className="text-2xl font-bold text-[#E3001C]">
                      {order.deliveryFee || 0} GNF
                    </p>
                  </div>
                  <div className="text-right flex-1">
                    <p className="text-xs text-[#666666]">
                      {new Date(order.createdAt).toLocaleDateString("fr-FR")}
                    </p>
                    <p className="text-sm font-semibold text-[#1A1A1A]">
                      {new Date(order.createdAt).toLocaleTimeString("fr-FR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  {order.status === "in_transit" || order.status === "accepted" ? (
                    <Button
                      onClick={() => setLocation(`/chat/${order.id}`)}
                      className="bg-[#009460] hover:bg-[#007A4A] text-white font-semibold py-2 px-4 rounded-lg flex items-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      Chat
                    </Button>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
