import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, MapPin, Star, Bike, Truck, Phone, MessageSquare } from "lucide-react";

interface Driver {
  id: number;
  name: string;
  transportType: "bike" | "motorcycle";
  rating: number;
  reviews: number;
  distance: number;
  pricePerKm: number;
  zone: string;
  avatar: string;
  isOnline: boolean;
  completedDeliveries: number;
}

const mockDrivers: Driver[] = [
  {
    id: 1,
    name: "Mamadou Diallo",
    transportType: "bike",
    rating: 4.8,
    reviews: 127,
    distance: 0.5,
    pricePerKm: 5,
    zone: "Dixinn",
    avatar: "👨‍🚴",
    isOnline: true,
    completedDeliveries: 342,
  },
  {
    id: 2,
    name: "Ismaël Camara",
    transportType: "motorcycle",
    rating: 4.6,
    reviews: 89,
    distance: 1.2,
    pricePerKm: 5,
    zone: "Kaloum",
    avatar: "👨‍🏍",
    isOnline: true,
    completedDeliveries: 215,
  },
  {
    id: 3,
    name: "Sory Diallo",
    transportType: "bike",
    rating: 4.9,
    reviews: 156,
    distance: 0.8,
    pricePerKm: 5,
    zone: "Matoto",
    avatar: "👨‍🚴",
    isOnline: true,
    completedDeliveries: 428,
  },
  {
    id: 4,
    name: "Abdoulaye Bah",
    transportType: "motorcycle",
    rating: 4.7,
    reviews: 103,
    distance: 2.1,
    pricePerKm: 5,
    zone: "Ratoma",
    avatar: "👨‍🏍",
    isOnline: false,
    completedDeliveries: 287,
  },
];

export default function AvailableDrivers() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [sortBy, setSortBy] = useState<"distance" | "rating" | "price">("distance");

  const sortedDrivers = [...mockDrivers].sort((a, b) => {
    if (sortBy === "distance") return a.distance - b.distance;
    if (sortBy === "rating") return b.rating - a.rating;
    if (sortBy === "price") return a.pricePerKm - b.pricePerKm;
    return 0;
  });

  const handleSelectDriver = (driver: Driver) => {
    setSelectedDriver(driver);
  };

  const handleOrderWithDriver = (driver: Driver) => {
    // Navigate to order form with driver pre-selected
    setLocation("/quick-order");
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
          </button>
          <h1 className="text-2xl font-bold text-[#1A1A1A]">Livreurs Disponibles</h1>
        </div>
      </header>

      {/* Sort Options */}
      <div className="container py-6">
        <div className="flex gap-3 overflow-x-auto pb-4">
          <button
            onClick={() => setSortBy("distance")}
            className={`px-4 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
              sortBy === "distance"
                ? "bg-[#E3001C] text-white"
                : "bg-white text-[#666666] border border-[#E0E0E0]"
            }`}
          >
            📍 Plus proche
          </button>
          <button
            onClick={() => setSortBy("rating")}
            className={`px-4 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
              sortBy === "rating"
                ? "bg-[#E3001C] text-white"
                : "bg-white text-[#666666] border border-[#E0E0E0]"
            }`}
          >
            ⭐ Meilleure note
          </button>
          <button
            onClick={() => setSortBy("price")}
            className={`px-4 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
              sortBy === "price"
                ? "bg-[#E3001C] text-white"
                : "bg-white text-[#666666] border border-[#E0E0E0]"
            }`}
          >
            💰 Moins cher
          </button>
        </div>
      </div>

      {/* Drivers Grid */}
      <div className="container pb-8">
        <div className="grid md:grid-cols-2 gap-4">
          {sortedDrivers.map((driver) => (
            <div
              key={driver.id}
              onClick={() => handleSelectDriver(driver)}
              className={`bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all cursor-pointer border-2 ${
                selectedDriver?.id === driver.id
                  ? "border-[#E3001C] bg-[#E3001C]/5"
                  : "border-transparent"
              }`}
            >
              {/* Driver Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="text-5xl">{driver.avatar}</div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-[#1A1A1A]">{driver.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Star className="w-4 h-4 text-[#FCD116] fill-[#FCD116]" />
                      <span className="font-semibold text-[#1A1A1A]">{driver.rating}</span>
                      <span className="text-xs text-[#666666]">({driver.reviews})</span>
                    </div>
                  </div>
                </div>
                {driver.isOnline ? (
                  <div className="flex items-center gap-1 bg-[#009460]/10 px-3 py-1 rounded-full">
                    <div className="w-2 h-2 bg-[#009460] rounded-full"></div>
                    <span className="text-xs font-semibold text-[#009460]">En ligne</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 bg-[#E0E0E0]/10 px-3 py-1 rounded-full">
                    <div className="w-2 h-2 bg-[#666666] rounded-full"></div>
                    <span className="text-xs font-semibold text-[#666666]">Hors ligne</span>
                  </div>
                )}
              </div>

              {/* Driver Info */}
              <div className="space-y-2 mb-4 pb-4 border-b border-[#E0E0E0]">
                <div className="flex items-center gap-2 text-sm text-[#666666]">
                  {driver.transportType === "bike" ? (
                    <Bike className="w-4 h-4 text-[#009460]" />
                  ) : (
                    <Truck className="w-4 h-4 text-[#E3001C]" />
                  )}
                  <span>{driver.transportType === "bike" ? "Vélo" : "Moto"}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-[#666666]">
                  <MapPin className="w-4 h-4 text-[#E3001C]" />
                  <span>{driver.zone}</span>
                  <span className="ml-auto font-semibold text-[#1A1A1A]">
                    {driver.distance} km
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-[#666666]">
                  <span>📊 {driver.completedDeliveries} livraisons</span>
                  <span className="ml-auto font-semibold text-[#E3001C]">
                    {driver.pricePerKm} GNF/km
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={() => handleOrderWithDriver(driver)}
                  className="flex-1 bg-[#E3001C] hover:bg-[#C70016] text-white font-semibold py-3 rounded-xl transition-colors"
                >
                  Commander
                </Button>
                <Button
                  variant="outline"
                  className="px-4 border-[#E0E0E0] hover:bg-[#F5F5F5]"
                >
                  <Phone className="w-5 h-5 text-[#E3001C]" />
                </Button>
                <Button
                  variant="outline"
                  className="px-4 border-[#E0E0E0] hover:bg-[#F5F5F5]"
                >
                  <MessageSquare className="w-5 h-5 text-[#009460]" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Driver Details Modal */}
      {selectedDriver && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-white w-full rounded-t-3xl p-6 max-h-[80vh] overflow-y-auto">
            <button
              onClick={() => setSelectedDriver(null)}
              className="absolute top-4 right-4 p-2 hover:bg-[#F5F5F5] rounded-lg"
            >
              ✕
            </button>

            <div className="flex items-center gap-4 mb-6">
              <div className="text-6xl">{selectedDriver.avatar}</div>
              <div>
                <h2 className="text-2xl font-bold text-[#1A1A1A]">{selectedDriver.name}</h2>
                <div className="flex items-center gap-2 mt-2">
                  <Star className="w-5 h-5 text-[#FCD116] fill-[#FCD116]" />
                  <span className="font-bold text-[#1A1A1A]">{selectedDriver.rating}</span>
                  <span className="text-sm text-[#666666]">({selectedDriver.reviews} avis)</span>
                </div>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-[#F9F9F9] rounded-lg p-4">
                <p className="text-xs text-[#666666] mb-1">Zone de livraison</p>
                <p className="font-semibold text-[#1A1A1A]">{selectedDriver.zone}</p>
              </div>
              <div className="bg-[#F9F9F9] rounded-lg p-4">
                <p className="text-xs text-[#666666] mb-1">Tarif</p>
                <p className="font-semibold text-[#E3001C]">{selectedDriver.pricePerKm} GNF/km</p>
              </div>
              <div className="bg-[#F9F9F9] rounded-lg p-4">
                <p className="text-xs text-[#666666] mb-1">Livraisons complétées</p>
                <p className="font-semibold text-[#1A1A1A]">{selectedDriver.completedDeliveries}</p>
              </div>
            </div>

            <Button
              onClick={() => {
                handleOrderWithDriver(selectedDriver);
                setSelectedDriver(null);
              }}
              className="w-full bg-[#E3001C] hover:bg-[#C70016] text-white font-bold py-4 text-lg rounded-xl"
            >
              Commander avec {selectedDriver.name}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
