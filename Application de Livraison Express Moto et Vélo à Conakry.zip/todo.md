# LivraisonGN Pro - Project TODO

## Core Features

### Authentication & User Management
- [x] Authentification par numéro de téléphone (sans Gmail)
- [x] Inscription rapide du client (Nom, téléphone, adresse)
- [ ] Système de vérification par SMS
- [x] Gestion des rôles (Client, Livreur, Admin)

### Client Features
- [x] Formulaire de commande complet (produit, adresse, transport, instructions)
- [x] Calcul automatique des frais de livraison (1 km = 5 GNF)
- [ ] Partage de position GPS en temps réel
- [ ] Notifications locales (commande envoyée, en route, livrée)
- [x] Historique des commandes
- [x] Profil utilisateur et contact entreprise (+224 612 15 87 95)

### Communication & Integration
- [ ] Envoi automatique par WhatsApp
- [ ] Envoi automatique par SMS
- [ ] Envoi automatique par Appel téléphonique
- [ ] Intégration des 3 canaux de communication

### Delivery Features
- [x] Interface livreur (voir commandes disponibles)
- [x] Bouton "Accepter la livraison"
- [x] Calcul automatique des commissions (10%)
- [x] Tableau de bord livreur avec commissions

### Admin Features
- [x] Interface d'administration basique
- [x] Statistiques des commandes
- [ ] Gestion des livreurs actifs
- [ ] Tableau CRUD pour utilisateurs et commandes

## UI/UX & Design
- [x] Palette de couleurs guinéenne (Rouge, Jaune, Vert)
- [x] Design avec coins arrondis et fond clair
- [x] Icônes minimalistes
- [x] Animations fluides et transitions
- [ ] Effet de chargement (loading) style Uber Eats
- [ ] Animation livreur sur la carte
- [x] Boutons flottants ("Commander maintenant", "Appeler livreur")
- [ ] Notifications avec vibrations et sons
- [x] Responsive design (mobile + ordinateur)

## Database & Backend
- [x] Schéma de base de données (Utilisateurs, Commandes, Transactions, Livreurs)
- [x] Stockage local des commandes
- [x] API tRPC pour toutes les fonctionnalités
- [x] Calcul des frais basé sur la distance GPS
- [x] Gestion des statuts de commande

## Pages & Navigation
- [x] Page d'accueil avec logo animation
- [x] Page de commande (formulaire)
- [ ] Page de suivi en direct avec carte GPS
- [x] Historique des commandes
- [ ] Profil utilisateur
- [x] Interface livreur
- [x] Interface admin
- [x] Page de contact entreprise

## Testing & Optimization
- [ ] Tests des fonctionnalités principales
- [ ] Optimisation de la performance
- [ ] Tests de compatibilité mobile/ordinateur
- [ ] Tests hors ligne (PWA)
- [ ] Vérification des animations et effets

## Documentation & Delivery
- [ ] Documentation utilisateur (userGuide.md)
- [ ] Guide d'administration
- [ ] Déploiement sur Manus
- [ ] Checkpoint final

---

## Notes
- Paiement: Cash à la livraison uniquement
- Calcul prix: Distance GPS × 5 GNF par km
- Commission livreur: 10% des frais de livraison
- Numéro fixe: +224 612 15 87 95 (visible partout)
- Type: PWA (Progressive Web App) - compatible mobile et ordinateur


## Nouvelles Fonctionnalités (Phase 5)

### Chat WebSocket
- [x] Implémentation du serveur WebSocket (Socket.io)
- [x] Chat direct client-livreur en temps réel
- [x] Historique des messages
- [ ] Notifications de nouveaux messages

### Partage de Position
- [x] Géolocalisation GPS au premier lancement
- [x] Partage automatique de position via Google Maps
- [x] Lien Google Maps envoyé par WhatsApp
- [x] Option de saisie manuelle de l'adresse

### Formulaire de Commande Rapide
- [x] Mode "Rapide" - Saisie libre du contenu
- [x] Champ pour notes spéciales ("pas trop épicé", "livrer à 14h")
- [x] Bouton pour basculer entre mode rapide et complet
- [ ] Sauvegarde des commandes récentes

### Mode de Contact
- [x] Choix du canal de contact (WhatsApp, SMS, Appel)
- [ ] Envoi automatique de confirmation par canal choisi
- [ ] Numéro de suivi de commande


## Phase 6 - Espace Livreurs & Clients

### Espace Livreurs
- [x] Inscription livreur (nom, numéro, moto/vélo, zone)
- [x] Tableau de bord livreur (poster disponibilités)
- [x] Profil public livreur (photo, notes ⭐, distance, tarif/km)
- [ ] Système de notation (⭐ après chaque livraison)
- [ ] Notifications instantanées (client sélectionne profil)
- [ ] Réception commande par SMS/WhatsApp (avec GPS)
- [ ] Historique des commandes livreur
- [x] Statistiques livreur (commandes, revenus, notes)

### Espace Clients
- [x] Liste des livreurs disponibles (photo, tarif, note, distance)
- [x] Profil détaillé du livreur
- [x] Bouton "Commander avec ce livreur"
- [x] Formulaire de commande simplifié
- [ ] Envoi automatique par WhatsApp/SMS
- [ ] Suivi en temps réel de la livraison
- [x] Historique des commandes client
- [ ] Notation du livreur après livraison

### Automatisations
- [x] GPS partagé automatiquement
- [ ] WhatsApp API (wa.me) pour envoi messages
- [ ] SMS API pour notifications
- [ ] Notifications instantanées (push)
- [x] Calcul distance automatique


## Phase 7 - Messages & Partage GPS en Temps Réel

### Système de Messages
- [x] Chat bid irectionnel client-livreur
- [x] Historique des messages persistant
- [ ] Notifications de nouveaux messages
- [x] Indicateur "en train de taper"
- [x] Horodatage des messages

### Partage GPS Automatique
- [x] Bouton "Partager ma position" dans formulaire commande
- [x] Mise à jour GPS toutes les 2 secondes
- [x] Affichage position en temps réel sur carte
- [x] Partage bid irectionnel (client ↔ livreur)
- [ ] Historique des positions

### Intégration Chat + GPS
- [x] Affichage position dans le chat
- [x] Lien Google Maps dans messages
- [ ] Notification quand position change
- [x] Calcul distance en temps réel
- [ ] ETA (temps d'arrivée estimé)
