import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  orders: router({
    create: protectedProcedure
      .input((input: any) => input)
      .mutation(async ({ ctx, input }) => {
        const { createOrder } = await import("./db");
        const order = await createOrder({
          clientId: ctx.user.id,
          productName: input.productName,
          deliveryAddress: input.deliveryAddress,
          transportType: input.transportType,
          specialInstructions: input.specialInstructions,
          clientLatitude: input.clientLatitude,
          clientLongitude: input.clientLongitude,
          deliveryLatitude: input.deliveryLatitude,
          deliveryLongitude: input.deliveryLongitude,
          distanceKm: input.distanceKm,
          deliveryFee: input.deliveryFee,
          status: "pending",
        });
        return order;
      }),
    getMyOrders: protectedProcedure.query(async ({ ctx }) => {
      const { getOrdersByClientId } = await import("./db");
      return getOrdersByClientId(ctx.user.id);
    }),
    getAvailable: publicProcedure.query(async () => {
      const { getAvailableOrders } = await import("./db");
      return getAvailableOrders();
    }),
  }),

  drivers: router({
    register: protectedProcedure
      .input((input: any) => input)
      .mutation(async ({ ctx, input }) => {
        const { createDriver } = await import("./db");
        const driver = await createDriver({
          userId: ctx.user.id,
          transportType: input.transportType,
          isActive: 1,
        });
        return driver;
      }),
    getMyInfo: protectedProcedure.query(async ({ ctx }) => {
      const { getDriverByUserId } = await import("./db");
      return getDriverByUserId(ctx.user.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
