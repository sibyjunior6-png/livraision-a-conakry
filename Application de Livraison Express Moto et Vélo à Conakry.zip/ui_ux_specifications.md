# Spécifications UI/UX de l'Application "LivraisonGN Pro"

## 1. Principes de Design
L'interface utilisateur (UI) sera conçue pour être **moderne, légère et rapide**, en s'inspirant du style **Figma** avec des transitions fluides et des animations subtiles. L'accent est mis sur l'accessibilité et la simplicité pour une **inscription rapide** et une **commande en quelques clics**.

## 2. Palette de Couleurs (Style Guinéen)

La palette est directement inspirée du drapeau de la Guinée (Rouge, Jaune, Vert) pour une identité visuelle forte et locale.

| Couleur | Code Hexadécimal | Utilisation Principale |
| :--- | :--- | :--- |
| **Rouge Primaire** | `#E3001C` | Boutons d'action principaux ("Commander maintenant", "Accepter la livraison"), indicateurs d'erreur. |
| **Jaune Secondaire** | `#FCD116` | Éléments d'accentuation, icônes de notification, indicateurs de statut "En attente". |
| **Vert Tertiaire** | `#009460` | Indicateurs de succès ("Livraison terminée"), icônes de validation. |
| **Fond Clair** | `#F9F9F9` | Arrière-plan principal des écrans. |
| **Texte Sombre** | `#1A1A1A` | Texte principal, titres. |
| **Ombres/Bords** | `#E0E0E0` | Bords arrondis, séparateurs, ombres portées légères. |

## 3. Typographie et Style Général
*   **Police de Caractères :** Une police sans-serif moderne et lisible (ex: Inter, Roboto) sera utilisée pour garantir la clarté sur mobile.
*   **Coins Arrondis :** Tous les conteneurs, cartes (cards), champs de formulaire et boutons auront des **coins très arrondis** (rayon de bordure élevé) pour un look "doux" et moderne.
*   **Fond :** Le fond sera principalement **clair** (`#F9F9F9`) pour mettre en valeur le contenu et les couleurs primaires.
*   **Icônes :** **Icônes minimalistes** (lignes fines ou remplissage léger) pour une esthétique épurée.

## 4. Spécifications des Écrans Principaux

### 4.1. Écran d'Accueil (Page 1)
*   **Structure :** Centrée et minimaliste.
*   **Contenu :**
    *   **Logo :** Animation fluide du logo "LivraisonGN Pro" au centre (animation d'entrée).
    *   **Slogan :** "Livraison Express Moto & Vélo à Conakry".
    *   **Bouton Flottant Principal :** **"Faire une commande"** (Rouge Primaire, grande taille, flottant en bas de l'écran).
    *   **Lien Secondaire :** "Historique des commandes" (en bas de page).

### 4.2. Page de Commande (Formulaire Complet - Page 2)
*   **Structure :** Formulaire défilant avec des champs bien espacés et arrondis.
*   **Champs :**
    1.  **Nom du client** (Champ texte arrondi)
    2.  **Téléphone** (Champ texte arrondi, avec préfixe +224)
    3.  **Adresse de livraison** (Champ texte arrondi, avec icône de localisation)
    4.  **Nom du plat ou produit** (Champ texte arrondi)
    5.  **Moyen de transport** (Boutons de sélection : 🚲 Vélo / 🏍 Moto - icônes claires, couleur Jaune/Vert pour l'option sélectionnée).
    6.  **Instructions spéciales** (Champ de texte multiligne arrondi)
*   **Action :** Bouton **"Valider la commande"** (Rouge Primaire).

### 4.3. Page de Suivi en Direct (Page 3)
*   **Structure :** Carte GPS en haut (70% de l'écran), panneau d'information en bas (30%).
*   **Carte GPS :**
    *   Affichage de la position du client et du livreur.
    *   **Animation :** L'icône du livreur (moto ou vélo) doit avoir une **animation de mouvement fluide** sur la carte.
    *   **Trajet :** Ligne de trajet claire entre le point de collecte et le point de livraison.
*   **Panneau d'Information :**
    *   Statut de la commande (ex: "Livreur en route 🚴‍♂️").
    *   Temps estimé d'arrivée.
    *   Frais de livraison calculés (basés sur la distance GPS).
    *   **Bouton Flottant :** **"Appeler livreur"** (Vert Tertiaire, icône de téléphone, flottant au-dessus du panneau).

### 4.4. Historique des Commandes (Page 4)
*   **Structure :** Liste de cartes (cards) pour chaque commande.
*   **Contenu de la Carte :** Nom du produit, date, statut (avec pastille de couleur : Vert pour Livrée, Jaune pour En cours, Rouge pour Annulée).

### 4.5. Profil Utilisateur et Contact (Page 5)
*   **Contenu :**
    *   Informations du client (Nom, Téléphone, Adresse).
    *   Section "Contact Entreprise" :
        *   Numéro fixe : **+224 612 15 87 95** (cliquable).
        *   Boutons d'action pour WhatsApp, SMS, Appel (icônes minimalistes).

## 5. Animations et Interactions
*   **Effet de Chargement (Loading) :** Un effet de chargement personnalisé, inspiré d'Uber Eats (ex: une petite icône de moto/vélo qui se déplace en boucle ou une vague de couleur Rouge/Jaune/Vert).
*   **Transitions :** Utilisation de transitions CSS fluides (ex: `ease-in-out`) pour les changements d'écran et les mises à jour de statut.
*   **Notifications :** Les notifications locales seront accompagnées de **vibrations courtes** et d'un **son moderne** pour chaque changement d'état.
*   **Boutons :** Effet de pression (scale down) subtil au clic.

## 6. Interface Livreur et Admin (Esquisse)
*   **Interface Livreur :** Tableau de bord simple avec une liste des commandes "En attente". Chaque commande est une carte avec l'adresse et le bouton **"Accepter la livraison"** (Rouge Primaire). Un onglet "Mes livraisons" affiche les commandes acceptées et le **tableau des commissions** (10% calculées).
*   **Interface Admin :** Tableau de bord avec des graphiques de statistiques basiques (nombre de commandes par jour, commissions totales) et des tableaux filtrables pour la gestion des utilisateurs et des commandes.
