import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Truck, Bike, MapPin, Phone, DollarSign, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function DriverDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedTab, setSelectedTab] = useState("available");

  const { data: availableOrders = [] } = trpc.orders.getAvailable.useQuery();
  const { data: driverInfo } = trpc.drivers.getMyInfo.useQuery();

  const acceptOrderMutation = trpc.orders.create.useMutation({
    onSuccess: () => {
      alert("Commande acceptée avec succès!");
    },
  });

  const handleAcceptOrder = (orderId: number) => {
    acceptOrderMutation.mutate({
      id: orderId,
      status: "accepted",
    } as any);
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/")}
              className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
            </button>
            <h1 className="text-2xl font-bold text-[#1A1A1A]">Tableau de Bord Livreur</h1>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => setLocation("/driver-availability")}
              className="bg-[#FCD116] hover:bg-[#E6B800] text-[#1A1A1A] font-semibold py-2 px-4 rounded-lg flex items-center gap-2"
            >
              <Zap className="w-5 h-5" />
              Mes Disponibilités
            </Button>
            <div className="text-right">
              <p className="text-sm text-[#666666]">{user?.name}</p>
              <p className="text-xs text-[#009460] font-semibold">En ligne</p>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="container py-6">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-[#666666] mb-1">Commissions Totales</p>
            <p className="text-2xl font-bold text-[#E3001C]">
              {driverInfo?.totalCommission || 0} GNF
            </p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-[#666666] mb-1">Livraisons Complétées</p>
            <p className="text-2xl font-bold text-[#009460]">
              {driverInfo?.completedDeliveries || 0}
            </p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-[#666666] mb-1">Type de Transport</p>
            <p className="text-lg font-bold text-[#FCD116]">
              {driverInfo?.transportType === "bike" ? "🚲 Vélo" : "🏍 Moto"}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="container">
        <div className="flex gap-4 border-b border-[#E0E0E0]">
          <button
            onClick={() => setSelectedTab("available")}
            className={`py-4 px-6 font-semibold border-b-2 transition-colors ${
              selectedTab === "available"
                ? "border-[#E3001C] text-[#E3001C]"
                : "border-transparent text-[#666666] hover:text-[#1A1A1A]"
            }`}
          >
            Commandes Disponibles ({availableOrders.length})
          </button>
          <button
            onClick={() => setSelectedTab("active")}
            className={`py-4 px-6 font-semibold border-b-2 transition-colors ${
              selectedTab === "active"
                ? "border-[#E3001C] text-[#E3001C]"
                : "border-transparent text-[#666666] hover:text-[#1A1A1A]"
            }`}
          >
            Mes Livraisons
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8">
        {selectedTab === "available" && (
          <div className="space-y-4">
            {availableOrders.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center">
                <Truck className="w-16 h-16 text-[#E0E0E0] mx-auto mb-4" />
                <h2 className="text-xl font-bold text-[#1A1A1A] mb-2">
                  Aucune commande disponible
                </h2>
                <p className="text-[#666666]">
                  Revenez plus tard pour voir les nouvelles commandes
                </p>
              </div>
            ) : (
              availableOrders.map((order: any) => (
                <div
                  key={order.id}
                  className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-[#1A1A1A]">{order.productName}</h3>
                      <p className="text-sm text-[#666666] mt-1 flex items-center gap-2">
                        {order.transportType === "bike" ? (
                          <Bike className="w-4 h-4" />
                        ) : (
                          <Truck className="w-4 h-4" />
                        )}
                        {order.transportType === "bike" ? "Vélo" : "Moto"}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-[#666666]">Commission</p>
                      <p className="text-2xl font-bold text-[#009460]">
                        {Math.round((order.deliveryFee || 0) * 0.1)} GNF
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4 pb-4 border-b border-[#E0E0E0]">
                    <div className="flex items-center gap-2 text-sm text-[#666666]">
                      <MapPin className="w-4 h-4 text-[#E3001C]" />
                      <span>{order.deliveryAddress}</span>
                    </div>
                    {order.specialInstructions && (
                      <div className="text-sm text-[#666666]">
                        <span className="font-semibold">Instructions:</span> {order.specialInstructions}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-3">
                    <Button
                      onClick={() => handleAcceptOrder(order.id)}
                      className="flex-1 bg-[#E3001C] hover:bg-[#C70016] text-white font-semibold py-3 rounded-xl transition-colors"
                    >
                      Accepter la Livraison
                    </Button>
                    <Button
                      variant="outline"
                      className="px-4 border-[#E0E0E0] hover:bg-[#F5F5F5]"
                    >
                      <Phone className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {selectedTab === "active" && (
          <div className="bg-white rounded-2xl p-12 text-center">
            <Truck className="w-16 h-16 text-[#E0E0E0] mx-auto mb-4" />
            <h2 className="text-xl font-bold text-[#1A1A1A] mb-2">Aucune livraison active</h2>
            <p className="text-[#666666]">Acceptez une commande pour commencer une livraison</p>
          </div>
        )}
      </div>
    </div>
  );
}
