import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Bike, Truck, MapPin, ArrowLeft } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Order() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    productName: "",
    deliveryAddress: "",
    transportType: "bike",
    specialInstructions: "",
    clientLatitude: "",
    clientLongitude: "",
    deliveryLatitude: "",
    deliveryLongitude: "",
    distanceKm: "0",
    deliveryFee: "0",
  });

  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: () => {
      alert("Commande créée avec succès!");
      setLocation("/history");
    },
    onError: (error) => {
      alert("Erreur lors de la création de la commande: " + error.message);
    },
  });

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleTransportChange = (type: string) => {
    setFormData((prev) => ({
      ...prev,
      transportType: type,
    }));
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    if (!formData.productName || !formData.deliveryAddress) {
      alert("Veuillez remplir tous les champs obligatoires");
      return;
    }

    createOrderMutation.mutate({
      ...formData,
      distanceKm: "5",
      deliveryFee: 25,
    });
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-[#F5F5F5] rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#1A1A1A]" />
          </button>
          <h1 className="text-2xl font-bold text-[#1A1A1A]">Nouvelle Commande</h1>
        </div>
      </header>

      {/* Form Container */}
      <div className="container py-8">
        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Product Name */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
                Nom du produit ou plat 🍗
              </label>
              <input
                type="text"
                name="productName"
                value={formData.productName}
                onChange={handleInputChange}
                placeholder="Ex: Riz gras, Poulet braisé..."
                className="w-full px-4 py-3 border border-[#E0E0E0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent"
              />
            </div>

            {/* Delivery Address */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-3 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#E3001C]" />
                Adresse de livraison 🏠
              </label>
              <input
                type="text"
                name="deliveryAddress"
                value={formData.deliveryAddress}
                onChange={handleInputChange}
                placeholder="Ex: Quartier Dixinn, près du marché..."
                className="w-full px-4 py-3 border border-[#E0E0E0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent"
              />
            </div>

            {/* Transport Type */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-4">
                Moyen de transport 🚚
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => handleTransportChange("bike")}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    formData.transportType === "bike"
                      ? "border-[#009460] bg-[#009460]/10"
                      : "border-[#E0E0E0] hover:border-[#009460]"
                  }`}
                >
                  <Bike className="w-8 h-8 mx-auto mb-2 text-[#009460]" />
                  <p className="font-semibold text-[#1A1A1A]">Vélo</p>
                  <p className="text-xs text-[#666666]">Rapide & Écologique</p>
                </button>

                <button
                  type="button"
                  onClick={() => handleTransportChange("motorcycle")}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    formData.transportType === "motorcycle"
                      ? "border-[#E3001C] bg-[#E3001C]/10"
                      : "border-[#E0E0E0] hover:border-[#E3001C]"
                  }`}
                >
                  <Truck className="w-8 h-8 mx-auto mb-2 text-[#E3001C]" />
                  <p className="font-semibold text-[#1A1A1A]">Moto</p>
                  <p className="text-xs text-[#666666]">Plus de capacité</p>
                </button>
              </div>
            </div>

            {/* Special Instructions */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-3">
                Instructions spéciales ✍️
              </label>
              <textarea
                name="specialInstructions"
                value={formData.specialInstructions}
                onChange={handleInputChange}
                placeholder="Ex: Pas de piment, livrer à la porte..."
                rows={3}
                className="w-full px-4 py-3 border border-[#E0E0E0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E3001C] focus:border-transparent resize-none"
              />
            </div>

            {/* Estimated Fee */}
            <div className="bg-gradient-to-r from-[#FCD116] to-[#009460] rounded-2xl p-6 text-white">
              <p className="text-sm font-semibold mb-2">Frais de livraison estimés</p>
              <p className="text-3xl font-bold">
                {formData.deliveryFee} GNF
              </p>
              <p className="text-xs mt-2 opacity-90">
                Calculé sur la base de la distance (1 km = 5 GNF)
              </p>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={createOrderMutation.isPending}
              className="w-full bg-[#E3001C] hover:bg-[#C70016] text-white font-bold py-4 text-lg rounded-xl transition-colors"
            >
              {createOrderMutation.isPending ? "Création en cours..." : "Valider la Commande"}
            </Button>

            {/* Contact Info */}
            <div className="bg-white rounded-2xl p-4 text-center border-l-4 border-[#FCD116]">
              <p className="text-sm text-[#666666]">
                Besoin d'aide ? Appelez-nous au{" "}
                <a href="tel:+224612158795" className="font-bold text-[#E3001C]">
                  +224 612 15 87 95
                </a>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
